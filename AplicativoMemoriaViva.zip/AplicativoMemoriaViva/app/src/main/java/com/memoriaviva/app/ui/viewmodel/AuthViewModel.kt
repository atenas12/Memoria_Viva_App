package com.memoriaviva.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.memoriaviva.app.data.local.db.AppDatabase
import com.memoriaviva.app.data.local.entities.UsuarioEntity
import com.memoriaviva.app.data.repository.AppRepository
import com.memoriaviva.app.util.DataStoreManager
import com.memoriaviva.app.util.HashUtil
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AuthViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val repo = AppRepository(db.usuarioDao(), db.idosoDao(), db.medicacaoDao(), db.alertaMedicacaoDao(), db.observacaoDao())
    private val dataStore = DataStoreManager(application)

    private val _state = MutableStateFlow<AuthState>(AuthState.Idle)
    val state = _state.asStateFlow()

    fun login(email: String, password: String) {
        viewModelScope.launch {
            _state.value = AuthState.Loading
            val user = repo.getUsuarioByEmail(email)
            if (user == null) {
                _state.value = AuthState.Error("Usuário não encontrado")
                return@launch
            }
            val hash = HashUtil.sha256(password)
            if (hash == user.senhaHash) {
                dataStore.saveSession(user.id_usuario, user.tipo)
                _state.value = AuthState.Success(user.id_usuario, user.tipo)
            } else {
                _state.value = AuthState.Error("Senha inválida")
            }
        }
    }

    fun register(
        cpf: String,
        nome: String,
        endereco: String,
        cep: String,
        email: String,
        password: String,
        tipo: String
    ) {
        viewModelScope.launch {
            _state.value = AuthState.Loading
            val exists = repo.getUsuarioByEmail(email)
            if (exists != null) {
                _state.value = AuthState.Error("Email já cadastrado")
                return@launch
            }
            val u = UsuarioEntity(
                cpf = cpf,
                nome = nome,
                endereco = endereco,
                cep = cep,
                email = email,
                senhaHash = HashUtil.sha256(password),
                tipo = tipo,
                data_cadastro = System.currentTimeMillis()
            )
            val id = repo.insertUsuario(u)
            dataStore.saveSession(id.toInt(), tipo)
            _state.value = AuthState.Success(id.toInt(), tipo)
        }
    }
}

sealed interface AuthState {
    object Idle : AuthState
    object Loading : AuthState
    data class Success(val userId: Int, val tipo: String) : AuthState
    data class Error(val message: String) : AuthState
}
