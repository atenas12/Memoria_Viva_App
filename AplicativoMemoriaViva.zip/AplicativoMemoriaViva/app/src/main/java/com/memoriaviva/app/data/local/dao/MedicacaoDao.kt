package com.memoriaviva.app.data.local.dao

import androidx.room.*
import com.memoriaviva.app.data.local.entities.MedicacaoEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MedicacaoDao {
    @Insert
    suspend fun insert(m: MedicacaoEntity): Long

    @Update
    suspend fun update(m: MedicacaoEntity)

    @Query("SELECT * FROM medicacoes WHERE id_idoso = :idIdoso ORDER BY horario")
    fun getByIdosoFlow(idIdoso: Int): Flow<List<MedicacaoEntity>>

    @Query("SELECT * FROM medicacoes WHERE id_medicacao = :id LIMIT 1")
    suspend fun getById(id: Int): MedicacaoEntity?
}
