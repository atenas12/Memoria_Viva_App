package com.memoriaviva.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.memoriaviva.app.data.local.entities.UsuarioEntity

@Dao
interface UsuarioDao {
    @Insert
    suspend fun insert(usuario: UsuarioEntity): Long

    @Query("SELECT * FROM usuarios WHERE email = :email LIMIT 1")
    suspend fun getByEmail(email: String): UsuarioEntity?

    @Query("SELECT * FROM usuarios WHERE id_usuario = :id LIMIT 1")
    suspend fun getById(id: Int): UsuarioEntity?
}
