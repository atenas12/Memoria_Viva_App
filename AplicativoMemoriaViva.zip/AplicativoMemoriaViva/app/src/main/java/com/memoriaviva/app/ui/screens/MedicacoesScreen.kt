package com.memoriaviva.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.memoriaviva.app.ui.viewmodel.MedicacaoViewModel
import com.memoriaviva.app.data.local.entities.MedicacaoEntity

@Composable
fun MedicacoesScreen(idIdoso: Int, onNavigate: (String) -> Unit, vm: MedicacaoViewModel = viewModel()) {
    var medicacoes by remember { mutableStateOf(listOf<MedicacaoEntity>()) }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text("Medicações do idoso #$idIdoso", style = MaterialTheme.typography.h6)
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            // ex: implementar AddMedicacaoScreen (rota não implementada nesta entrega mínima)
        }) {
            Text("Adicionar Medicacao")
        }
        Spacer(Modifier.height(8.dp))
        if (medicacoes.isEmpty()) {
            Text("Nenhuma medicação cadastrada", style = MaterialTheme.typography.body2)
        } else {
            medicacoes.forEach {
                Text("${it.nome_medicamento} - ${it.horario}")
            }
        }
    }
}
