package com.memoriaviva.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.memoriaviva.app.data.local.db.AppDatabase
import com.memoriaviva.app.data.local.entities.IdosoEntity
import com.memoriaviva.app.data.repository.AppRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class IdosoViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val repo = AppRepository(db.usuarioDao(), db.idosoDao(), db.medicacaoDao(), db.alertaMedicacaoDao(), db.observacaoDao())

    val idososFlow = repo.getAllIdososFlow()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun addIdoso(idoso: IdosoEntity, onComplete: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repo.insertIdoso(idoso)
            onComplete(id)
        }
    }

    fun updateIdoso(idoso: IdosoEntity) {
        viewModelScope.launch {
            repo.updateIdoso(idoso)
        }
    }
}
