package com.memoriaviva.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.memoriaviva.app.ui.navigation.Routes
import com.memoriaviva.app.ui.viewmodel.AuthState
import com.memoriaviva.app.ui.viewmodel.AuthViewModel

@Composable
fun RegisterScreen(
    onNavigate: (String) -> Unit,
    vm: AuthViewModel = viewModel()
) {
    val state by vm.state.collectAsState()
    var nome by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var senha by remember { mutableStateOf("") }
    var cpf by remember { mutableStateOf("") }
    var endereco by remember { mutableStateOf("") }
    var cep by remember { mutableStateOf("") }
    var tipo by remember { mutableStateOf("familiar") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Cadastro", style = MaterialTheme.typography.h5)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = nome, onValueChange = { nome = it }, label = { Text("Nome") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = senha, onValueChange = { senha = it }, label = { Text("Senha") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = cpf, onValueChange = { cpf = it }, label = { Text("CPF") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = endereco, onValueChange = { endereco = it }, label = { Text("Endereço") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = cep, onValueChange = { cep = it }, label = { Text("CEP") }, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(8.dp))
        Row {
            Text("Tipo: ")
            Spacer(Modifier.width(8.dp))
            Button(onClick = { tipo = "funcionario" }, colors = ButtonDefaults.buttonColors(backgroundColor = if (tipo == "funcionario") MaterialTheme.colors.primary else MaterialTheme.colors.surface)) {
                Text("Funcionário")
            }
            Spacer(Modifier.width(8.dp))
            Button(onClick = { tipo = "familiar" }, colors = ButtonDefaults.buttonColors(backgroundColor = if (tipo == "familiar") MaterialTheme.colors.primary else MaterialTheme.colors.surface)) {
                Text("Familiar")
            }
        }

        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            vm.register(cpf, nome, endereco, cep, email, senha, tipo)
        }, modifier = Modifier.fillMaxWidth()) {
            Text("Registrar")
        }

        Spacer(Modifier.height(10.dp))
        when (state) {
            AuthState.Loading -> CircularProgressIndicator()
            is AuthState.Error -> Text((state as AuthState.Error).message, color = MaterialTheme.colors.error)
            is AuthState.Success -> onNavigate(Routes.HOME)
            else -> {}
        }

        Spacer(Modifier.height(8.dp))
        TextButton(onClick = { onNavigate(Routes.LOGIN) }) {
            Text("Voltar ao login")
        }
    }
}
