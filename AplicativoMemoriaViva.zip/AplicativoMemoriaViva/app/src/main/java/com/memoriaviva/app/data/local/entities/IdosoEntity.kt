package com.memoriaviva.app.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "idosos",
    foreignKeys = [
        ForeignKey(
            entity = UsuarioEntity::class,
            parentColumns = ["id_usuario"],
            childColumns = ["responsavel_id"],
            onDelete = ForeignKey.SET_NULL
        )
    ]
)
data class IdosoEntity(
    @PrimaryKey(autoGenerate = true)
    val id_idoso: Int = 0,
    val nome_completo: String,
    val data_nascimento: String,
    val altura: Double?,
    val peso: Double?,
    val doencas_preexistentes: String?,
    val alergias: String?,
    val responsavel_id: Int?
)
