package com.memoriaviva.app.util

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("memoriaviva_prefs")

class DataStoreManager(private val context: Context) {
    companion object {
        val KEY_USER_ID = intPreferencesKey("key_user_id")
        val KEY_USER_TYPE = stringPreferencesKey("key_user_type")
        val KEY_LOGGED_IN = booleanPreferencesKey("key_logged_in")
    }

    suspend fun saveSession(userId: Int, userType: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_USER_ID] = userId
            prefs[KEY_USER_TYPE] = userType
            prefs[KEY_LOGGED_IN] = true
        }
    }

    suspend fun clearSession() {
        context.dataStore.edit { prefs ->
            prefs.clear()
        }
    }

    val sessionFlow: Flow<Pair<Int?, String?>> = context.dataStore.data.map { prefs ->
        val id = prefs[KEY_USER_ID]
        val type = prefs[KEY_USER_TYPE]
        Pair(id, type)
    }

    val isLoggedInFlow: Flow<Boolean> = context.dataStore.data.map { it[KEY_LOGGED_IN] ?: false }
}
