package com.memoriaviva.app.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "observacoes",
    foreignKeys = [
        ForeignKey(
            entity = IdosoEntity::class,
            parentColumns = ["id_idoso"],
            childColumns = ["id_idoso"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = UsuarioEntity::class,
            parentColumns = ["id_usuario"],
            childColumns = ["id_usuario"],
            onDelete = ForeignKey.SET_NULL
        )
    ]
)
data class ObservacaoEntity(
    @PrimaryKey(autoGenerate = true)
    val id_observacao: Int = 0,
    val id_idoso: Int,
    val id_usuario: Int?,
    val data_observacao_iso: String,
    val texto: String
)
