package com.memoriaviva.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.memoriaviva.app.ui.navigation.Routes

@Composable
fun HomeScreen(onNavigate: (String) -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Bem-vindo ao Memória Viva", style = MaterialTheme.typography.h5)
        Spacer(Modifier.height(20.dp))
        Button(onClick = { onNavigate(Routes.IDOSOS) }, modifier = Modifier.fillMaxWidth()) {
            Text("Idosos")
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { onNavigate(Routes.MEDICACOES_BASE) }, modifier = Modifier.fillMaxWidth()) {
            Text("Medicações")
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { /* Observações */ }, modifier = Modifier.fillMaxWidth()) {
            Text("Observações")
        }
    }
}
