package com.memoriaviva.app.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.memoriaviva.app.data.local.dao.*
import com.memoriaviva.app.data.local.entities.*

@Database(
    entities = [
        UsuarioEntity::class,
        IdosoEntity::class,
        MedicacaoEntity::class,
        AlertaMedicacaoEntity::class,
        ObservacaoEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun usuarioDao(): UsuarioDao
    abstract fun idosoDao(): IdosoDao
    abstract fun medicacaoDao(): MedicacaoDao
    abstract fun alertaMedicacaoDao(): AlertaMedicacaoDao
    abstract fun observacaoDao(): ObservacaoDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val inst = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "memoriaviva_db"
                ).fallbackToDestructiveMigration()
                    .build()
                INSTANCE = inst
                inst
            }
        }
    }
}
