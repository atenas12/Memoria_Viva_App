package com.memoriaviva.app.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "medicacoes",
    foreignKeys = [
        ForeignKey(
            entity = IdosoEntity::class,
            parentColumns = ["id_idoso"],
            childColumns = ["id_idoso"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class MedicacaoEntity(
    @PrimaryKey(autoGenerate = true)
    val id_medicacao: Int = 0,
    val id_idoso: Int,
    val nome_medicamento: String,
    val dose: String,
    val horario: String,
    val observacoes: String?
)
