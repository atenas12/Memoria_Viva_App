package com.memoriaviva.app.ui.navigation

object Routes {
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val HOME = "home"
    const val IDOSOS = "idosos"
    const val ADD_IDOSO = "add_idoso"
    const val MEDICACOES_BASE = "medicacoes"
    const val MEDICACOES = "medicacoes/{idIdoso}"
    const val OBSERVACOES = "observacoes/{idIdoso}"
}
