package com.memoriaviva.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ObservacoesScreen(idIdoso: Int, onNavigate: (String) -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text("Observações do idoso #$idIdoso", style = androidx.compose.material.MaterialTheme.typography.h6)
        Spacer(Modifier.height(8.dp))
        Text("Funcionalidade: registrar observações e listar o histórico")
    }
}
