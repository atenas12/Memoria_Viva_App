package com.memoriaviva.app.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.memoriaviva.app.util.NotificationHelper

class AlertaMedicacaoWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): Result {
        val titulo = inputData.getString("titulo") ?: "Lembrete"
        val texto = inputData.getString("texto") ?: "Hora da medicação"
        val notifId = inputData.getInt("notifId", 0)
        NotificationHelper.sendNotification(applicationContext, titulo, texto, notifId)
        return Result.success()
    }
}
