package com.memoriaviva.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.memoriaviva.app.data.local.entities.ObservacaoEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ObservacaoDao {
    @Insert
    suspend fun insert(obs: ObservacaoEntity): Long

    @Query("SELECT * FROM observacoes WHERE id_idoso = :idIdoso ORDER BY data_observacao_iso DESC")
    fun getByIdosoFlow(idIdoso: Int): Flow<List<ObservacaoEntity>>
}
