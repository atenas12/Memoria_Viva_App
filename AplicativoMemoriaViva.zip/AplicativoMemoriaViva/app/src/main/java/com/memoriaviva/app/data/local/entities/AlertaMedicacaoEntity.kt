package com.memoriaviva.app.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "alertas_medicacao",
    foreignKeys = [
        ForeignKey(
            entity = MedicacaoEntity::class,
            parentColumns = ["id_medicacao"],
            childColumns = ["id_medicacao"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class AlertaMedicacaoEntity(
    @PrimaryKey(autoGenerate = true)
    val id_alerta: Int = 0,
    val id_medicacao: Int,
    val horario_alerta_iso: String,
    val status: String
)
