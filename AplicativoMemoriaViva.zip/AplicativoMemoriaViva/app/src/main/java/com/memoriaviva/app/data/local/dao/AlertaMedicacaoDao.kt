package com.memoriaviva.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.memoriaviva.app.data.local.entities.AlertaMedicacaoEntity

@Dao
interface AlertaMedicacaoDao {
    @Insert
    suspend fun insert(alerta: AlertaMedicacaoEntity): Long

    @Query("SELECT * FROM alertas_medicacao WHERE status = :status")
    suspend fun getByStatus(status: String): List<AlertaMedicacaoEntity>

    @Query("UPDATE alertas_medicacao SET status = :status WHERE id_alerta = :id")
    suspend fun updateStatus(id: Int, status: String)
}
