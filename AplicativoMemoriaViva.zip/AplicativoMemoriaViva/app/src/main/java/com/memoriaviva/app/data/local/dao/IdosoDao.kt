package com.memoriaviva.app.data.local.dao

import androidx.room.*
import com.memoriaviva.app.data.local.entities.IdosoEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface IdosoDao {
    @Insert
    suspend fun insert(idoso: IdosoEntity): Long

    @Update
    suspend fun update(idoso: IdosoEntity)

    @Delete
    suspend fun delete(idoso: IdosoEntity)

    @Query("SELECT * FROM idosos ORDER BY nome_completo")
    fun getAllFlow(): Flow<List<IdosoEntity>>

    @Query("SELECT * FROM idosos WHERE id_idoso = :id LIMIT 1")
    suspend fun getById(id: Int): IdosoEntity?
}
