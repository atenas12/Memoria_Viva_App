package com.memoriaviva.app.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.memoriaviva.app.ui.navigation.AppNavHost
import com.memoriaviva.app.ui.theme.MemoriaVivaTheme
import com.memoriaviva.app.util.NotificationHelper

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationHelper.createChannelIfNeeded(this)
        setContent {
            MemoriaVivaTheme {
                AppNavHost()
            }
        }
    }
}
