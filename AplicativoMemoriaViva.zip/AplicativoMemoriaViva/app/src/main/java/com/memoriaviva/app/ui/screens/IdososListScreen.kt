package com.memoriaviva.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.memoriaviva.app.ui.viewmodel.IdosoViewModel
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import com.memoriaviva.app.data.local.entities.IdosoEntity

@Composable
fun IdososListScreen(onNavigate: (String) -> Unit, vm: IdosoViewModel = viewModel()) {
    val idosos by vm.idososFlow.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Lista de Idosos", style = MaterialTheme.typography.h6)
            Button(onClick = { onNavigate("add_idoso") }) {
                Text("Novo")
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            items(idosos) { idoso ->
                IdosoItem(idoso = idoso, onClick = { /* navegar para detalhes */ })
                Divider()
            }
        }
    }
}

@Composable
fun IdosoItem(idoso: IdosoEntity, onClick: () -> Unit) {
    Column(modifier = Modifier
        .fillMaxWidth()
        .clickable { onClick() }
        .padding(10.dp)
    ) {
        Text(idoso.nome_completo, style = MaterialTheme.typography.subtitle1)
        Text("Nascimento: ${idoso.data_nascimento}", style = MaterialTheme.typography.caption)
        if (!idoso.doencas_preexistentes.isNullOrBlank()) {
            Text("Doenças: ${idoso.doencas_preexistentes}", style = MaterialTheme.typography.body2)
        }
    }
}
