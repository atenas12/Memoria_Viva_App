package com.memoriaviva.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.*
import com.memoriaviva.app.data.local.db.AppDatabase
import com.memoriaviva.app.data.local.entities.MedicacaoEntity
import com.memoriaviva.app.data.local.entities.AlertaMedicacaoEntity
import com.memoriaviva.app.data.repository.AppRepository
import com.memoriaviva.app.worker.AlertaMedicacaoWorker
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit

class MedicacaoViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getInstance(application)
    private val repo = AppRepository(db.usuarioDao(), db.idosoDao(), db.medicacaoDao(), db.alertaMedicacaoDao(), db.observacaoDao())
    private val workManager = WorkManager.getInstance(application)

    fun addMedicacaoAndSchedule(medicacao: MedicacaoEntity, horarioIsoForAlert: String) {
        viewModelScope.launch {
            val newId = repo.insertMedicacao(medicacao).toInt()
            val alerta = AlertaMedicacaoEntity(
                id_medicacao = newId,
                horario_alerta_iso = horarioIsoForAlert,
                status = "ativo"
            )
            val alertaId = repo.insertAlerta(alerta).toInt()
            scheduleWork(alertaId, medicacao.nome_medicamento, medicacao.dose, horarioIsoForAlert)
        }
    }

    private fun scheduleWork(alertaId: Int, nomeMedicamento: String, dose: String, horarioIso: String) {
        val formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME
        val target = LocalDateTime.parse(horarioIso, formatter)
        val now = LocalDateTime.now()
        val delayMillis = java.time.Duration.between(now, target).toMillis()
        if (delayMillis <= 0) return

        val data = workDataOf(
            "titulo" to "Lembrete: $nomeMedicamento",
            "texto" to "Dose: $dose",
            "notifId" to alertaId
        )

        val request = OneTimeWorkRequestBuilder<AlertaMedicacaoWorker>()
            .setInitialDelay(delayMillis, TimeUnit.MILLISECONDS)
            .setInputData(data)
            .build()

        workManager.enqueue(request)
    }
}
