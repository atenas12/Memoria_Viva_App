package com.memoriaviva.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.composable
import com.memoriaviva.app.ui.screens.*

@Composable
fun AppNavHost(modifier: Modifier = Modifier) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Routes.LOGIN) {
        composable(Routes.LOGIN) {
            LoginScreen(onNavigate = { route -> navController.navigate(route) })
        }
        composable(Routes.REGISTER) {
            RegisterScreen(onNavigate = { route -> navController.navigate(route) })
        }
        composable(Routes.HOME) {
            HomeScreen(onNavigate = { route -> navController.navigate(route) })
        }
        composable(Routes.IDOSOS) {
            IdososListScreen(onNavigate = { route -> navController.navigate(route) })
        }
        composable(Routes.ADD_IDOSO) {
            AddIdosoScreen(onNavigate = { route -> navController.navigate(route) })
        }
        composable("medicacoes/{idIdoso}") { backEntry ->
            val id = backEntry.arguments?.getString("idIdoso")?.toIntOrNull() ?: 0
            MedicacoesScreen(idIdoso = id, onNavigate = { route -> navController.navigate(route) })
        }
        composable("observacoes/{idIdoso}") { backEntry ->
            val id = backEntry.arguments?.getString("idIdoso")?.toIntOrNull() ?: 0
            ObservacoesScreen(idIdoso = id, onNavigate = { route -> navController.navigate(route) })
        }
    }
}
