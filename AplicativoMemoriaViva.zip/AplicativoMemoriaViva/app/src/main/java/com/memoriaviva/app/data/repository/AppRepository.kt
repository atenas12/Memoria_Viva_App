package com.memoriaviva.app.data.repository

import com.memoriaviva.app.data.local.dao.*
import com.memoriaviva.app.data.local.entities.*
import kotlinx.coroutines.flow.Flow

class AppRepository(
    private val usuarioDao: UsuarioDao,
    private val idosoDao: IdosoDao,
    private val medicacaoDao: MedicacaoDao,
    private val alertaDao: AlertaMedicacaoDao,
    private val observacaoDao: ObservacaoDao
) {
    // Usuários
    suspend fun insertUsuario(u: UsuarioEntity) = usuarioDao.insert(u)
    suspend fun getUsuarioByEmail(email: String) = usuarioDao.getByEmail(email)
    suspend fun getUsuarioById(id: Int) = usuarioDao.getById(id)

    // Idosos
    suspend fun insertIdoso(i: IdosoEntity) = idosoDao.insert(i)
    suspend fun updateIdoso(i: IdosoEntity) = idosoDao.update(i)
    suspend fun getIdosoById(id: Int) = idosoDao.getById(id)
    fun getAllIdososFlow(): Flow<List<IdosoEntity>> = idosoDao.getAllFlow()

    // Medicacoes
    suspend fun insertMedicacao(m: MedicacaoEntity) = medicacaoDao.insert(m)
    suspend fun updateMedicacao(m: MedicacaoEntity) = medicacaoDao.update(m)
    fun getMedicacoesByIdosoFlow(idIdoso: Int) = medicacaoDao.getByIdosoFlow(idIdoso)
    suspend fun getMedicacaoById(id: Int) = medicacaoDao.getById(id)

    // Alertas
    suspend fun insertAlerta(a: AlertaMedicacaoEntity) = alertaDao.insert(a)
    suspend fun getAlertasByStatus(status: String) = alertaDao.getByStatus(status)
    suspend fun updateAlertaStatus(id: Int, status: String) = alertaDao.updateStatus(id, status)

    // Observacoes
    suspend fun insertObservacao(o: ObservacaoEntity) = observacaoDao.insert(o)
    fun getObservacoesByIdosoFlow(idIdoso: Int) = observacaoDao.getByIdosoFlow(idIdoso)
}
