package com.memoriaviva.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.memoriaviva.app.ui.viewmodel.IdosoViewModel
import com.memoriaviva.app.data.local.entities.IdosoEntity

@Composable
fun AddIdosoScreen(onNavigate: (String) -> Unit, vm: IdosoViewModel = viewModel()) {
    var nome by remember { mutableStateOf("") }
    var dataNasc by remember { mutableStateOf("") }
    var altura by remember { mutableStateOf("") }
    var peso by remember { mutableStateOf("") }
    var doencas by remember { mutableStateOf("") }
    var alergias by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Cadastrar Idoso", style = MaterialTheme.typography.h6)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = nome, onValueChange = { nome = it }, label = { Text("Nome completo") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = dataNasc, onValueChange = { dataNasc = it }, label = { Text("Data de nascimento (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = altura, onValueChange = { altura = it }, label = { Text("Altura (m)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = peso, onValueChange = { peso = it }, label = { Text("Peso (kg)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = doencas, onValueChange = { doencas = it }, label = { Text("Doenças pré-existentes") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = alergias, onValueChange = { alergias = it }, label = { Text("Alergias") }, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            val idoso = IdosoEntity(
                nome_completo = nome,
                data_nascimento = dataNasc,
                altura = altura.toDoubleOrNull(),
                peso = peso.toDoubleOrNull(),
                doencas_preexistentes = doencas,
                alergias = alergias,
                responsavel_id = null
            )
            vm.addIdoso(idoso) { _ -> onNavigate("idosos") }
        }, modifier = Modifier.fillMaxWidth()) {
            Text("Salvar")
        }

        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { onNavigate("idosos") }, modifier = Modifier.fillMaxWidth()) {
            Text("Cancelar")
        }
    }
}
